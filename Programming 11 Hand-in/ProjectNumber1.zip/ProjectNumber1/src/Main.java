public class Main {
    //Code your solution to problem number one here
    static int problemOne(String s){
        int answer = 0;
        //your code here
        for(int i = 0; i < s.length(); i++) {
            if(s.split("")[i].equals("a") || s.split("")[i].equals("e") || s.split("")[i].equals("i") || s.split("")[i].equals("o") || s.split("")[i].equals("u")) {
                answer++;
            }
            //if the i+1'th character is a, e, i, o, or u, increment the answer, so that the answer increments only when a vowel occurs.
        }
        return answer;
    }
    //Code you problem number two here
    static int problemTwo(String s){
        int answer = 0;
        //your code here
        for(int i = 0; i < s.length()-2; i++) {
            if(s.split("")[i].equals("b") && s.split("")[i+1].equals("o") && s.split("")[i+2].equals("b")) {
                answer++;
            }
            //if the i+1'th character is b and the two letters after are o and b respectively, increment the answer. Do not need to check for a double-used b.
        }

        return answer;
    }
    //Code your solution to problem number 3 here
    static String problemThree(String s){
        //your code here
        String longString = "Longest substring in alphabetical order is: ";
        String[] alphabet = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
        String answer = "";
        int counter = 0;
        int[] indices = new int [s.length()];
        int[] alphOrder = new int [s.length()];
        int endIndex = 0;
        int longestChain = 0;
        /*
        indices will represent each letter as an integer.
        alphOrder will represent the chains of letters in alphabetical order.
        For example, if s is "bcdefgfghabdf",
                   B  C  D  E  F  G  F  G  H  A  B  D  F
        indices = [1, 2, 3, 4, 5, 6, 5, 6, 7, 0, 1, 3, 5]
        alphOrder=[0, 1, 2, 3, 4, 5, 0, 1, 2, 0, 1, 2, 3]
        counter will represent the values of each individual value in the alphOrder array,
        and longestChain will represent the length of the longest chain of increasing values while we are counting them.
        In this example, after setting alphOrder with the values listed above, counter will be:
        counter =  0  1  2  3  4  5  5  5  5  5  5  5  5
                    -------------------------------------> time
        So at the end, after we have looped through alphOrder, counter will represent the length of the longest chain of characters - 1.
        endIndex is rather self explanatory, it marks the index at which the longest chain of characters has ended.
        In this case, it would be index 5, since our longest chain of characters (bcdefg) starts at index 0 and ends at index 5 with a total length of 6.
        longString is an unchanging string that will serve as the format for our print statement. This name is not a mistake. longString is indeed relatively long.
        answer is our answer.
        Now that we understand what all the values are doing, let's set them!
         */
        for(int i = 0; i < s.length(); i++) {
            for(int m = 0; m < alphabet.length; m++) {
                if(s.split("")[i].equals(alphabet[m])) {
                    indices[i] = m;
                }
                //for each letter that is in string s, loop through the alphabet array once. the alphabet array is used as a lookup to relate the string letters to their indices.
                //note the use of s.split. usually, this function splits the string into an array containing all the letters until a certain regular expression pattern. however, since I did not
                //input a pattern, it splits the string into an array of strings of length 1. (counting from 1)
                //FOR EXAMPLE:
                //String s = "bcdefgfghabdf";
                //s.split("") is equal to {"b", "c", "d", "e", "f", "g", "f", "g", "h", "a", "b", "d", "f"}
                //very useful in parsing strings character by character.
            }
        }
        for(int x = 0; x < indices.length-1; x++) {
            alphOrder[x] = counter;
            if(indices[x] <= indices[x+1]) {
                counter++;
            } else {
                counter = 0;
            }
            /*Now, we need to set alphOrder. To do this:
            1) the counter is 0
            2) increment the counter when the next value in indices is larger than the current value
            3) reset the counter when we encounter a value in indices where the value AFTER IT IS LESS.
            in the example mentioned earlier:
            indices = [1, 2, 3, 4, 5, 6, 5, 6, 7, 0, 1, 3, 5]
            for x = 0:
                indices[x] = 1
                indices[x+1] = 2 (the next value in the array)
                2 > 1, therefore we increment the counter from 0 to 1
            for x = 5:
                indices[x] = 6
                indices[x+1] = 5
                6 > 5 is FALSE, so counter is reset to 0
            this way, when we set alphOrder to counter, we will get the values we want.
            alphOrder=[0, 1, 2, 3, 4, 5, 0, 1, 2, 0, 1, 2, ?]
            note that when we evaluate indices[x+1] for x when we are at the end of the array, we will encounter an error.
            We will set this value outside of the array...
            */
        }
        if(indices[indices.length-1] >= indices[indices.length-2]) {
            alphOrder[alphOrder.length-1] = alphOrder[alphOrder.length-2]+1;
        }
        else {
            alphOrder[alphOrder.length - 1] = 0;
        }
        /*right here. We set alphOrder based on the value from indices. if the character continues the alphabetical order chain, we set the last value of alphOrder to the second last value + 1.
        FOR EXAMPLE:
        indices = [1, 2, 3, 4, 5, 6, 5, 6, 7, 0, 1, 3, 5]
        alphOrder=[0, 1, 2, 3, 4, 5, 0, 1, 2, 0, 1, 2, ?]
        5 is greater than 3, so it continues the alphabetical order chain! the second last value is 2, so the last value will be 2+1 or 3
        alphOrder=[0, 1, 2, 3, 4, 5, 0, 1, 2, 0, 1, 2, 3]
        SECOND EXAMPLE:
        indices = [8, 9, 10, 11, 3, 2]
        alphOrder=[0, 1, 2,  3,  0, ?]
        since 2 is not greater than or equal to 3, it must not continue the alphabetical order chain. Thus, the last value is set to 0.
        */
        for (int j = 0; j < alphOrder.length; j++) {
            if(alphOrder[j] > longestChain) {
                longestChain = alphOrder[j];
                //if the current value in alphOrder is larger than the length of the longest chain, that means that there is a longer chain.
                //thus, we must update the value of the length of the longest chain to reflect that.
                endIndex = j;
                //similarly, we must update the endIndex to the current index, since the longest chain might end here.
                //if the chain turns out to be longer, no matter. we simply update the values again.
            }
        }
        /*let's look again at our example.
            INDEX    0  1  2  3  4  5  6  7  8  9 10 11 12
          indices = [1, 2, 3, 4, 5, 6, 5, 6, 7, 0, 1, 3, 5]
          alphOrder=[0, 1, 2, 3, 4, 5, 0, 1, 2, 0, 1, 2, 3]
          longestChain = 5 (if you're confused, remember to count from 0!)
          endIndex = 5
          in order for a for loop to work, we need to know the starting and ending values of what we're looping through.
          to find the start index, we just need to get the end index and subtract the length of the longestChain.
          the end index is obviously endIndex.
          thus, we start at endIndex-longestChain, and we count until AND INCLUDING endIndex.
         */
        for(int u = endIndex-longestChain; u <= endIndex; u++) {
            answer += s.split("")[u];
            //basically add the letter at the index onto shortString.
        }
        System.out.println(longString + answer);
        //print the formatted output
        return answer;
        //return the correct answer ONLY
    }
    public static void main(String[] args) {
        /*
        Set s to a string and run your method using s as the parameter
        Run your method in a println statement to determine what the output was
        Once you think you have it working try running the tests.
        The tests will put your method through several different Strings to test
        all possible cases.  If you have 100% success then there is no bugs in your methods.
         */
        String s;
    }
}
