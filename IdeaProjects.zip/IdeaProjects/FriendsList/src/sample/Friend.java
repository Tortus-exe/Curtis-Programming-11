package sample;

import javafx.collections.ObservableList;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.Buffer;

public class Friend {
    private final static File dataFile = new File("FriendsData.txt");
    private String firstname;
    private String lastname;
    private int age;
    private String description;

    Friend(String fname, String lname, int age, String desc) {
        this.firstname = fname;
        this.lastname = lname;
        this.age = age;
        this.description = desc;
    }

    Friend() {
        this.firstname = "FirstName";
        this.lastname = "LastName";
        this.age = 0;
        this.description = "";
    }

    public int getAge() { return age; }
    public String getDescription() { return description; }
    public String getFirstname() { return firstname; }
    public String getLastname() { return lastname; }
    public static File getDataFile() { return dataFile; }

    public void setAge(int age) { this.age = age; }
    public void setDescription(String description) { this.description = description; }
    public void setFirstname(String firstname) { this.firstname = firstname; }
    public void setLastname(String lastname) { this.lastname = lastname; }

    @Override
    public String toString() {
        return firstname + " " + lastname;
    }

    public static void writeToFile(ObservableList<Friend> objsToWrite) {
        try {
            if(dataFile.createNewFile()) {
                dataFile.createNewFile();
            } else {
                dataFile.delete();
                dataFile.createNewFile();
            }
            //this will be ignored if a file already exists
            FileWriter fw = new FileWriter("FriendsData.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            for(Friend item : objsToWrite) {
                bw.write(item.getFirstname() + ", " + item.getLastname() + ", " + item.getAge() + ", " + item.getDescription() + "\r%%\r");
                //write in this format: FIRSTNAME, LASTNAME, AGE, DESC
                //                      %%
            }
            bw.flush();
        } catch (IOException e) {
            System.out.println("something odd happened!");
            e.printStackTrace();
        }
    }
}
