package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.io.*;
import java.util.ArrayList;

public class Controller {

    public ListView<Friend> friendsList;
    public Button AddFriendButton;
    public Button RemoveFriendButton;
    public TextField fnameBox;
    public TextField lnameBox;
    public TextField ageBox;
    public TextField descBox;
    public Button loadButton;

    private Friend temp;
    private int IndexOfItemBeforeTemp;
    private int caretPos;

    public void initialize() {
        if(Friend.getDataFile().exists()) {
            loadButton.setDisable(false);
        }
    }

    public void AddFriend(ActionEvent actionEvent) {
        temp = new Friend();
        if(friendsList.getItems().size()==0) {
            if (!fnameBox.getText().equals("")) {
                temp.setFirstname(fnameBox.getText());
            }
            if(!lnameBox.getText().equals("")) {
                temp.setLastname(lnameBox.getText());
            }
            if(!ageBox.getText().equals("")) {
                temp.setAge(Integer.parseInt(ageBox.getText()));
            }
            if(!descBox.getText().equals("")) {
                temp.setDescription(descBox.getText());
            }
        }
        IndexOfItemBeforeTemp = friendsList.getItems().indexOf(temp) - 1;
        friendsList.getItems().add(temp);
        friendsList.getSelectionModel().select(temp);

        displayFriend();
    }

    public void RemoveFriend(ActionEvent actionEvent) {
        temp = friendsList.getSelectionModel().getSelectedItem();
        IndexOfItemBeforeTemp = friendsList.getItems().indexOf(temp) - 1;
        friendsList.getItems().remove(temp);
        friendsList.getSelectionModel().select(IndexOfItemBeforeTemp);
        if(friendsList.getItems().size() == 0) {
            RemoveFriendButton.setDisable(true);
        }
    }

    public void updateFirstName(KeyEvent keyEvent) {
        if(friendsList.getItems().size() == 0) {
            return;
        }
        temp.setFirstname(fnameBox.getText());
        //always refresh the list cuz then the list has only old names in it
        friendsList.refresh();
    }

    public void updateLastName(KeyEvent keyEvent) {
        if(friendsList.getItems().size() == 0) {
            return;
        }
        temp.setLastname(lnameBox.getText());
        friendsList.refresh();
    }

    public void updateAge(KeyEvent keyEvent) {
        if(!ageBox.getText().matches("[0-9]*")) {
            //get the position of the caret (the blinky line)
            caretPos = ageBox.getCaretPosition();
            ageBox.setText(ageBox.getText().replaceAll("[^0-9]", ""));
            //set the position of the caret to one character before the last typed character
            ageBox.positionCaret(caretPos-1);
        }
        if(friendsList.getItems().size() == 0) {
            return;
        }
        if(ageBox.getText().equals("")) {
            temp.setAge(0);
            return;
        }
        temp.setAge(Integer.parseInt(ageBox.getText()));
        friendsList.refresh();
    }

    public void updateDescription(KeyEvent keyEvent) {
        if(friendsList.getItems().size() == 0) {
            return;
        }
        temp.setDescription(descBox.getText());
        friendsList.refresh();
    }

    public void FriendWasClickedOn(MouseEvent mouseEvent) {
        displayFriend();
    }

    public void displayFriend() {
        if(temp.equals(null)) {
            return;
        }
        temp = friendsList.getSelectionModel().getSelectedItem();
        fnameBox.setText(friendsList.getSelectionModel().getSelectedItem().getFirstname());
        lnameBox.setText(friendsList.getSelectionModel().getSelectedItem().getLastname());
        ageBox.setText(Integer.toString(friendsList.getSelectionModel().getSelectedItem().getAge()));
        descBox.setText(friendsList.getSelectionModel().getSelectedItem().getDescription());
        if(friendsList.getSelectionModel().getSelectedItem() != null) {
            RemoveFriendButton.setDisable(false);
        } else {
            RemoveFriendButton.setDisable(true);
        }
    }

    public void LoadClicked() throws IOException {
        loadFriendsToList();
        if(friendsList.getItems().size() > 0) {
            RemoveFriendButton.setDisable(false);
        }
    }

    public void SaveClicked() throws IOException {
        Friend.writeToFile(friendsList.getItems());
    }

    public void loadFriendsToList() throws IOException {
        friendsList.getItems().clear();
        friendsList.getItems().addAll(ReadFromFile.loadFriendsFromFile());
    }
}
