package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class ReadFromFile {
    private static ArrayList<Friend> listOfFriendsInFile = new ArrayList<>();
    private static FileReader fr;
    private static BufferedReader br;

    public static ArrayList<Friend> loadFriendsFromFile() throws IOException {
        listOfFriendsInFile.clear();
        fr = new FileReader("FriendsData.txt");
        br = new BufferedReader(fr);
        String line;
        String unTranslatedFriendString = "";
        while((line = br.readLine()) != null) {
            if(!line.equals("%%")) {
                unTranslatedFriendString += line;
            } else {
                parseFriend(unTranslatedFriendString);
                unTranslatedFriendString = "";
            }
        }
        System.out.println(listOfFriendsInFile);
        return listOfFriendsInFile;
    }

    public static void parseFriend(String inputString) {
        String[] infoArray = inputString.split(",");
        for(int i = 1; i < infoArray.length; i++) {
            infoArray[i] = infoArray[i].substring(1);
        }
        listOfFriendsInFile.add(new Friend(infoArray[0], infoArray[1], Integer.parseInt(infoArray[2]), infoArray[3]));
    }
}
